package snake;

public class SnakeGame {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		GameFrame frame = new GameFrame();
	}

}
